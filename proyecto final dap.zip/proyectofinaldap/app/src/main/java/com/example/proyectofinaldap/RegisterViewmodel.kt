package com.example.proyectofinaldap

import androidx.lifecycle.ViewModel

class CrearUsuarioViewModel : ViewModel() {
}