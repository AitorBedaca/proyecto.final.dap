package com.example.proyectofinaldap

class superheroesProvider {
    private val superheroesList:MutableList<superheroes> = mutableListOf()
    init{
        superheroesList.add(superheroes("Batman"))
        superheroesList.add(superheroes("Superman"))
        superheroesList.add(superheroes("Acuaman"))
        superheroesList.add(superheroes("Flash"))
        superheroesList.add(superheroes("Spiderman"))
        superheroesList.add(superheroes("IronMan"))
        superheroesList.add(superheroes("SuperAle"))
    }
    fun Getsuperhero(): MutableList<superheroes>{
        return superheroesList
    }
}

