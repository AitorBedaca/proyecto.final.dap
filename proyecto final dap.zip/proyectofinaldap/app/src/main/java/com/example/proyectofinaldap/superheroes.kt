package com.example.proyectofinaldap

class superheroes (
    val nombre : String
    ) {
}