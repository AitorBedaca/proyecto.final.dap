package com.example.proyectofinaldap

class descripcionViewmodel {
}