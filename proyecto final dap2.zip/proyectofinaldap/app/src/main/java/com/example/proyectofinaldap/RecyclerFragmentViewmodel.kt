package com.example.proyectofinaldap

import androidx.lifecycle.ViewModel

class RecyclerFragmentViewmodel : ViewModel() {
    lateinit var nombre : String
    lateinit var desc : String
}